# ======================
# 데이터 모델 정의 : Cart
from .cart_item import CartItem


class Cart:
    def __init__(self, memberId):
        self.__memberId = memberId
        self.__items = []

    def get_memberId(self): return self.__memberId
    def get_member_id(self): return self.__memberId
    def get_items(self): return list(self.__items)

    def addItem(self, product, qty):
        for item in self.__items:
            if item.get_productNo() == product.get_productNo():
                item.set_quantity(item.get_quantity() + qty)
                return
        self.__items.append(CartItem(product.get_productNo(), product.get_name(), product.get_price(), qty))

    def updateQty(self, productNo, qty):
        for item in self.__items:
            if item.get_productNo() == productNo:
                item.set_quantity(qty)
                return True
        return False

    def removeItem(self, productNo):
        for item in list(self.__items):
            if item.get_productNo() == productNo:
                self.__items.remove(item)
                return True
        return False

    def clear(self):
        self.__items = []

    def isEmpty(self):
        return len(self.__items) == 0

    def getTotal(self):
        return sum(item.getSubtotal() for item in self.__items)
