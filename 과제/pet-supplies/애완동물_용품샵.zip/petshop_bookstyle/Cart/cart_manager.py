# ======================
# 장바구니 관리 : CartManager
import os
import pickle
from .cart import Cart


class CartManager:
    DB_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'DB', 'cartDB.obj')

    def __init__(self, productMgr):
        self.__productMgr = productMgr
        self.__cartDB = self.__load()

    def __load(self):
        try:
            if os.path.exists(CartManager.DB_FILE):
                with open(CartManager.DB_FILE, 'rb') as f:
                    data = pickle.load(f)
                    if isinstance(data, dict):
                        return data
        except Exception:
            pass
        return {}

    def __save(self):
        os.makedirs(os.path.dirname(CartManager.DB_FILE), exist_ok=True)
        with open(CartManager.DB_FILE, 'wb') as f:
            pickle.dump(self.__cartDB, f)

    def getCart(self, memberId):
        if memberId not in self.__cartDB:
            self.__cartDB[memberId] = Cart(memberId)
            self.__save()
        return self.__cartDB[memberId]

    def addItem(self, memberId, productNo, qty):
        product = self.__productMgr.getProduct(productNo)
        if not product:
            return False, '존재하지 않는 상품입니다.'
        if product.get_stock() < qty:
            return False, f'재고 부족 (현재 재고: {product.get_stock()}개)'
        self.getCart(memberId).addItem(product, qty)
        self.__save()
        return True, '장바구니에 담았습니다.'

    def updateQty(self, memberId, productNo, qty):
        product = self.__productMgr.getProduct(productNo)
        if product and product.get_stock() < qty:
            return False
        result = self.getCart(memberId).updateQty(productNo, qty)
        self.__save()
        return result

    def removeItem(self, memberId, productNo):
        result = self.getCart(memberId).removeItem(productNo)
        self.__save()
        return result

    def clearCart(self, memberId):
        self.getCart(memberId).clear()
        self.__save()

    # snake_case 별칭
    def get_cart(self, memberId): return self.getCart(memberId)
    def add_item(self, memberId, productNo, qty): return self.addItem(memberId, productNo, qty)
    def update_qty(self, memberId, productNo, qty): return self.updateQty(memberId, productNo, qty)
    def remove_item(self, memberId, productNo): return self.removeItem(memberId, productNo)
    def clear_cart(self, memberId): return self.clearCart(memberId)
