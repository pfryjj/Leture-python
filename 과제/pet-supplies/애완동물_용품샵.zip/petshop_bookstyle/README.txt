애완동물 용품샵 - 온라인서점 스타일 수정본

실행 방법
1. 압축을 풉니다.
2. 터미널에서 이 폴더로 이동합니다.
3. python petshop.py 또는 python main.py 를 실행합니다.

관리자 계정
- ID : admin
- PW : admin1234

구조
- petshop.py : PetShopApp, MenuController
- Auth/auth_manager.py : AuthManager
- Member/member.py, member_manager.py : Member, MemberManager
- Product/product.py, product_manager.py : Product, ProductManager
- Cart/cart.py, cart_item.py, cart_manager.py : Cart, CartItem, CartManager
- Order/order.py, order_item.py, order_manager.py : Order, OrderItem, OrderManager
- Delivery/delivery.py, delivery_manager.py : Delivery, DeliveryManager
- DB/*.obj : 실행 후 자동 생성되는 저장 파일

반영 기준
- 메뉴구성도: 비회원 메뉴 / 회원 메뉴 / 관리자 메뉴 그대로 반영
- 유스케이스: 상품 조회/검색, 회원가입, 장바구니, 주문, 주문 취소, 배송 조회, 관리자 상품/회원/주문/배송 관리 반영
- 클래스다이어그램: PetShopApp, MenuController, AuthManager, MemberManager, ProductManager, CartManager, OrderManager, DeliveryManager와 주요 도메인 클래스 반영
- 온라인서점 스타일: 패키지 분리, Manager 클래스, getter/setter, 메뉴 리스트, 콘솔 입출력 방식 사용
