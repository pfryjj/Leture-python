# ======================
# 주문 관리 : OrderManager
import os
import pickle
from datetime import date
from .order import Order
from .order_item import OrderItem


class OrderManager:
    DB_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'DB', 'orderDB.obj')

    def __init__(self, cartMgr, productMgr):
        self.__cartMgr = cartMgr
        self.__productMgr = productMgr
        self.__orderDB = self.__load()
        self.__seq = max(self.__orderDB.keys(), default=0) + 1

    def __load(self):
        try:
            if os.path.exists(OrderManager.DB_FILE):
                with open(OrderManager.DB_FILE, 'rb') as f:
                    data = pickle.load(f)
                    if isinstance(data, dict):
                        return data
        except Exception:
            pass
        return {}

    def __save(self):
        os.makedirs(os.path.dirname(OrderManager.DB_FILE), exist_ok=True)
        with open(OrderManager.DB_FILE, 'wb') as f:
            pickle.dump(self.__orderDB, f)

    def createOrder(self, memberId):
        cart = self.__cartMgr.getCart(memberId)
        if cart.isEmpty():
            return None, '장바구니가 비어 있습니다.'

        for item in cart.get_items():
            product = self.__productMgr.getProduct(item.get_productNo())
            if not product:
                return None, f'{item.get_productName()} 상품이 존재하지 않습니다.'
            if product.get_stock() < item.get_quantity():
                return None, f'{product.get_name()} 재고가 부족합니다.'

        order_items = [
            OrderItem(item.get_productNo(), item.get_productName(), item.get_price(), item.get_quantity())
            for item in cart.get_items()
        ]
        order = Order(self.__seq, memberId, order_items, date.today().isoformat(), '주문완료')
        self.__orderDB[self.__seq] = order
        self.__seq += 1

        for item in order_items:
            self.__productMgr.reduceStock(item.get_productNo(), item.get_quantity())
        self.__cartMgr.clearCart(memberId)
        self.__save()
        return order, '주문이 완료되었습니다.'

    def listOrders(self, memberId):
        return [o for o in self.__orderDB.values() if o.get_memberId() == memberId]

    def listAllOrders(self):
        return list(self.__orderDB.values())

    def getOrder(self, orderNo):
        return self.__orderDB.get(orderNo)

    def cancelOrder(self, orderNo):
        order = self.getOrder(orderNo)
        if not order or order.get_status() == '주문취소':
            return False
        for item in order.get_items():
            self.__productMgr.restoreStock(item.get_productNo(), item.get_quantity())
        order.set_status('주문취소')
        self.__save()
        return True

    def updateStatus(self, orderNo, status):
        order = self.getOrder(orderNo)
        if not order:
            return False
        order.set_status(status)
        self.__save()
        return True

    # snake_case 별칭
    def create_order(self, memberId): return self.createOrder(memberId)
    def list_orders(self, memberId): return self.listOrders(memberId)
    def list_all_orders(self): return self.listAllOrders()
    def get_order(self, orderNo): return self.getOrder(orderNo)
    def cancel_order(self, orderNo): return self.cancelOrder(orderNo)
    def update_status(self, orderNo, status): return self.updateStatus(orderNo, status)
