# ======================
# 배송 관리 : DeliveryManager
import os
import pickle
from datetime import date
from .delivery import Delivery


class DeliveryManager:
    DB_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'DB', 'deliveryDB.obj')

    def __init__(self):
        self.__deliveryDB = self.__load()
        self.__seq = max((d.get_deliveryNo() for d in self.__deliveryDB.values()), default=0) + 1

    def __load(self):
        try:
            if os.path.exists(DeliveryManager.DB_FILE):
                with open(DeliveryManager.DB_FILE, 'rb') as f:
                    data = pickle.load(f)
                    if isinstance(data, dict):
                        return data
        except Exception:
            pass
        return {}

    def __save(self):
        os.makedirs(os.path.dirname(DeliveryManager.DB_FILE), exist_ok=True)
        with open(DeliveryManager.DB_FILE, 'wb') as f:
            pickle.dump(self.__deliveryDB, f)

    def createDelivery(self, orderNo, address):
        delivery = Delivery(self.__seq, orderNo, address, '배송준비', date.today().isoformat())
        self.__deliveryDB[orderNo] = delivery
        self.__seq += 1
        self.__save()
        return delivery

    def getDelivery(self, orderNo):
        return self.__deliveryDB.get(orderNo)

    def updateStatus(self, orderNo, status):
        delivery = self.getDelivery(orderNo)
        if not delivery:
            return False
        delivery.set_status(status)
        delivery.set_updatedDate(date.today().isoformat())
        self.__save()
        return True

    def markOrderCanceled(self, orderNo):
        delivery = self.getDelivery(orderNo)
        if delivery:
            delivery.set_status('주문취소')
            delivery.set_updatedDate(date.today().isoformat())
            self.__save()

    # snake_case 별칭
    def create_delivery(self, orderNo, address): return self.createDelivery(orderNo, address)
    def get_delivery(self, orderNo): return self.getDelivery(orderNo)
    def update_status(self, orderNo, status): return self.updateStatus(orderNo, status)
