from petshop import PetShopApp


if __name__ == '__main__':
    PetShopApp().main()
