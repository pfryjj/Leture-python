# ======================
# 데이터 모델 정의 : Product
class Product:
    def __init__(self, name, category, price, stock, productNo=0, regDate=''):
        self.__productNo = productNo
        self.__name = name
        self.__category = category
        self.__price = price
        self.__stock = stock
        self.__regDate = regDate

    def get_productNo(self): return self.__productNo
    def get_product_no(self): return self.__productNo
    def get_name(self): return self.__name
    def get_category(self): return self.__category
    def get_price(self): return self.__price
    def get_stock(self): return self.__stock
    def get_regDate(self): return self.__regDate
    def get_reg_date(self): return self.__regDate

    def set_productNo(self, no): self.__productNo = no
    def set_product_no(self, no): self.__productNo = no
    def set_name(self, name): self.__name = name
    def set_category(self, category): self.__category = category
    def set_price(self, price): self.__price = price
    def set_stock(self, stock): self.__stock = stock
    def set_regDate(self, regDate): self.__regDate = regDate

    def __str__(self):
        return (f'[{self.__productNo:>3}] {self.__name:<18} | {self.__category:<8} | '
                f'{self.__price:>8,}원 | 재고 {self.__stock:>3}개')
