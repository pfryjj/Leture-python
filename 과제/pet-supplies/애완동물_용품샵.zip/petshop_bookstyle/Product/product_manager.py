# ======================
# 상품 관리 : ProductManager
import os
import pickle
from datetime import date
from .product import Product


class ProductManager:
    DB_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'DB', 'productDB.obj')

    def __init__(self):
        self.__productDB = self.__load()
        self.__seq = max(self.__productDB.keys(), default=0) + 1
        if not self.__productDB:
            self.__init_sample_products()

    def __load(self):
        try:
            if os.path.exists(ProductManager.DB_FILE):
                with open(ProductManager.DB_FILE, 'rb') as f:
                    data = pickle.load(f)
                    if isinstance(data, dict):
                        return data
        except Exception:
            pass
        return {}

    def __save(self):
        os.makedirs(os.path.dirname(ProductManager.DB_FILE), exist_ok=True)
        with open(ProductManager.DB_FILE, 'wb') as f:
            pickle.dump(self.__productDB, f)

    def __init_sample_products(self):
        samples = [
            Product('강아지 사료 2kg', '사료', 25000, 30),
            Product('고양이 모래 10L', '위생용품', 18000, 20),
            Product('원목 스크래쳐', '장난감', 32000, 10),
            Product('자동 급식기', '용품', 54000, 5),
            Product('반려동물 샴푸', '미용용품', 12000, 15),
        ]
        for product in samples:
            self.addProduct(product)

    def listProducts(self):
        return list(self.__productDB.values())

    def search(self, keyword):
        keyword = keyword.strip().lower()
        return [p for p in self.__productDB.values()
                if keyword in p.get_name().lower() or keyword in p.get_category().lower()]

    def getProduct(self, no):
        return self.__productDB.get(no)

    def addProduct(self, product):
        product.set_productNo(self.__seq)
        product.set_regDate(date.today().isoformat())
        self.__productDB[self.__seq] = product
        self.__seq += 1
        self.__save()
        return True

    def updateProduct(self, product):
        no = product.get_productNo()
        if no in self.__productDB:
            self.__productDB[no] = product
            self.__save()
            return True
        return False

    def deleteProduct(self, no):
        if no in self.__productDB:
            del self.__productDB[no]
            self.__save()
            return True
        return False

    def reduceStock(self, no, qty):
        product = self.getProduct(no)
        if not product or product.get_stock() < qty:
            return False
        product.set_stock(product.get_stock() - qty)
        self.__save()
        return True

    def restoreStock(self, no, qty):
        product = self.getProduct(no)
        if not product:
            return False
        product.set_stock(product.get_stock() + qty)
        self.__save()
        return True

    # snake_case 별칭
    def list_products(self): return self.listProducts()
    def get_product(self, no): return self.getProduct(no)
    def add_product(self, product): return self.addProduct(product)
    def update_product(self, product): return self.updateProduct(product)
    def delete_product(self, no): return self.deleteProduct(no)
