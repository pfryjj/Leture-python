# ======================
# 회원 관리 : MemberManager
import os
import pickle
from datetime import date
from .member import Member


class MemberManager:
    DB_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'DB', 'memberDB.obj')

    def __init__(self):
        self.__memberDB = self.__load()
        if 'admin' not in self.__memberDB:
            admin = Member('admin', 'admin1234', '관리자', '010-0000-0000', '본사',
                           date.today().isoformat(), True)
            self.__memberDB['admin'] = admin
            self.__save()

    def __load(self):
        try:
            if os.path.exists(MemberManager.DB_FILE):
                with open(MemberManager.DB_FILE, 'rb') as f:
                    data = pickle.load(f)
                    if isinstance(data, dict):
                        return data
        except Exception:
            pass
        return {}

    def __save(self):
        os.makedirs(os.path.dirname(MemberManager.DB_FILE), exist_ok=True)
        with open(MemberManager.DB_FILE, 'wb') as f:
            pickle.dump(self.__memberDB, f)

    def join(self, member):
        if member.get_id() in self.__memberDB:
            return False
        if not member.get_joinDate():
            member.set_joinDate(date.today().isoformat())
        self.__memberDB[member.get_id()] = member
        self.__save()
        return True

    def getMember(self, id):
        return self.__memberDB.get(id)

    def listMembers(self):
        return list(self.__memberDB.values())

    def deleteMember(self, id):
        if id == 'admin':
            return False
        if id in self.__memberDB:
            del self.__memberDB[id]
            self.__save()
            return True
        return False

    # 온라인서점 코드 스타일 호환용 별칭
    def get_member(self, id): return self.getMember(id)
    def list_members(self): return self.listMembers()
    def delete_member(self, id): return self.deleteMember(id)
