from Member.member import Member
from Member.member_manager import MemberManager
from Auth.auth_manager import AuthManager
from Product.product import Product
from Product.product_manager import ProductManager
from Cart.cart_manager import CartManager
from Order.order_manager import OrderManager
from Delivery.delivery_manager import DeliveryManager


class PetShopApp:
    def main(self):
        MenuController().start()


class MenuController:
    guest_menu          = ['종료',    '상품 목록 조회', '상품 검색', '회원가입', '로그인']
    member_menu         = ['로그아웃', '상품 목록/검색', '장바구니 관리', '주문하기', '주문 조회/상세', '주문 취소', '배송 상세 조회', '내 정보 조회']
    admin_menu          = ['로그아웃', '상품 관리', '회원 관리', '전체 주문 조회', '배송 상태 수정']
    product_lookup_menu = ['뒤로',    '상품 목록 조회', '상품 검색']
    cart_menu           = ['뒤로',    '장바구니 조회', '장바구니 담기', '수량 수정', '상품 삭제', '전체 비우기']
    product_manage_menu = ['뒤로',    '상품 목록 조회', '상품 등록', '상품 수정', '상품 삭제']
    member_manage_menu  = ['뒤로',    '회원 목록', '회원 상세 조회', '회원 삭제']

    def __init__(self):
        self.productMgr = ProductManager()
        self.memberMgr = MemberManager()
        self.authMgr = AuthManager(self.memberMgr)
        self.cartMgr = CartManager(self.productMgr)
        self.orderMgr = OrderManager(self.cartMgr, self.productMgr)
        self.deliveryMgr = DeliveryManager()
        self.__running = True

    # ----------------------------------------------------------
    # 공통 UI 헬퍼 — 온라인서점 코드 스타일과 동일한 방식
    # ----------------------------------------------------------
    def print_menu(self, menu_list, title=None):
        print('-' * 44)
        if title:
            print(f'  {title}')
            print('-' * 44)
        for i in range(1, len(menu_list)):
            print(f'  {i}. {menu_list[i]}')
        print(f'  0. {menu_list[0]}')
        print('-' * 44)

    def select_menu(self, menu_list, title=None):
        self.print_menu(menu_list, title)
        try:
            return int(input('메뉴 선택 : '))
        except ValueError:
            return -1

    def header(self, title):
        print(f'\n{"=" * 44}')
        print(f'  {title}')
        print('=' * 44)

    # ----------------------------------------------------------
    # 메인 흐름
    # ----------------------------------------------------------
    def start(self):
        print('=' * 44)
        print(f'{"애완동물 용품샵":^40}')
        print('=' * 44)
        while self.__running:
            if not self.authMgr.authenticate():
                self.guestMenu()
            elif self.authMgr.checkRole('admin'):
                self.adminMenu()
            else:
                self.memberMenu()
        print('\n  이용해 주셔서 감사합니다.')

    def guestMenu(self):
        menu = self.select_menu(MenuController.guest_menu, '비회원 메뉴')
        if menu == 0:
            self.__running = False
        elif menu == 1:
            self.listProducts()
        elif menu == 2:
            self.searchProduct()
        elif menu == 3:
            self.joinMember()
        elif menu == 4:
            self.login()
        else:
            print('  없는 메뉴입니다.')

    def memberMenu(self):
        user = self.authMgr.getLoginUser()
        menu = self.select_menu(MenuController.member_menu, f'[ {user.get_id()} ] 회원 메뉴')
        if menu == 0:
            self.authMgr.logout()
            print('  로그아웃되었습니다.')
        elif menu == 1:
            self.productLookupMenu()
        elif menu == 2:
            self.cartMenu()
        elif menu == 3:
            self.orderProduct()
        elif menu == 4:
            self.viewOrderListAndDetail()
        elif menu == 5:
            self.cancelOrder()
        elif menu == 6:
            self.viewDeliveryDetail()
        elif menu == 7:
            self.viewMyInfo()
        else:
            print('  없는 메뉴입니다.')

    def adminMenu(self):
        menu = self.select_menu(MenuController.admin_menu, '관리자 메뉴')
        if menu == 0:
            self.authMgr.logout()
            print('  로그아웃되었습니다.')
        elif menu == 1:
            self.productManageMenu()
        elif menu == 2:
            self.memberManageMenu()
        elif menu == 3:
            self.listAllOrders()
        elif menu == 4:
            self.updateDeliveryStatus()
        else:
            print('  없는 메뉴입니다.')

    # ----------------------------------------------------------
    # 비회원/인증
    # ----------------------------------------------------------
    def joinMember(self):
        self.header('회원가입')
        id = input('>> ID       : ').strip()
        password = input('>> 비밀번호 : ').strip()
        name = input('>> 이름     : ').strip()
        phone = input('>> 전화번호 : ').strip()
        address = input('>> 주소     : ').strip()

        if not id or not password or not name:
            print('  ID, 비밀번호, 이름은 필수입니다.')
            return

        member = Member(id, password, name, phone, address)
        if self.memberMgr.join(member):
            print('  회원가입이 완료되었습니다.')
        else:
            print('  이미 사용 중인 ID입니다.')

    def login(self):
        self.header('로그인')
        id = input('>> ID       : ').strip()
        password = input('>> 비밀번호 : ').strip()
        if self.authMgr.login(id, password):
            print(f'\n  {id}님, 환영합니다!')
        else:
            print('  로그인에 실패하였습니다.')

    # ----------------------------------------------------------
    # 상품 조회/검색
    # ----------------------------------------------------------
    def productLookupMenu(self):
        while True:
            menu = self.select_menu(MenuController.product_lookup_menu, '상품 목록/검색')
            if menu == 0:
                break
            elif menu == 1:
                self.listProducts()
            elif menu == 2:
                self.searchProduct()
            else:
                print('  없는 메뉴입니다.')

    def listProducts(self):
        self.header('상품 목록')
        products = self.productMgr.listProducts()
        if not products:
            print('  등록된 상품이 없습니다.')
            return False
        print(f'  {"번호":>4}  {"상품명":<18} {"분류":<8} {"가격":>8}  {"재고":>4}')
        print('  ' + '-' * 56)
        for p in products:
            print(f'  [{p.get_productNo():>3}] {p.get_name():<18} {p.get_category():<8} '
                  f'{p.get_price():>8,}원  {p.get_stock():>3}개')
        return True

    def searchProduct(self):
        self.header('상품 검색')
        keyword = input('검색어(상품명/카테고리) : ').strip()
        results = self.productMgr.search(keyword)
        if not results:
            print('  검색 결과가 없습니다.')
        else:
            for p in results:
                print(f'  {p}')

    # ----------------------------------------------------------
    # 장바구니 관리
    # ----------------------------------------------------------
    def cartMenu(self):
        while True:
            menu = self.select_menu(MenuController.cart_menu, '장바구니 관리')
            if menu == 0:
                break
            elif menu == 1:
                self.viewCart()
            elif menu == 2:
                self.addCartItem()
            elif menu == 3:
                self.updateCartQty()
            elif menu == 4:
                self.removeCartItem()
            elif menu == 5:
                self.clearCart()
            else:
                print('  없는 메뉴입니다.')

    def viewCart(self):
        self.header('장바구니')
        memberId = self.authMgr.getLoginUser().get_id()
        cart = self.cartMgr.getCart(memberId)
        if cart.isEmpty():
            print('  장바구니가 비어 있습니다.')
            return False
        for item in cart.get_items():
            print(f'  {item}')
        print(f'  {"합계":>35} {cart.getTotal():,}원')
        return True

    def addCartItem(self):
        self.listProducts()
        try:
            productNo = int(input('담을 상품 번호 : '))
            qty = int(input('수량           : '))
        except ValueError:
            print('  올바른 값을 입력하세요.')
            return
        if qty <= 0:
            print('  수량은 1개 이상이어야 합니다.')
            return
        memberId = self.authMgr.getLoginUser().get_id()
        ok, msg = self.cartMgr.addItem(memberId, productNo, qty)
        print(f'  {msg}')

    def updateCartQty(self):
        if not self.viewCart():
            return
        try:
            productNo = int(input('수정할 상품 번호 : '))
            qty = int(input('변경할 수량      : '))
        except ValueError:
            print('  올바른 값을 입력하세요.')
            return
        if qty <= 0:
            print('  수량은 1개 이상이어야 합니다.')
            return
        memberId = self.authMgr.getLoginUser().get_id()
        if self.cartMgr.updateQty(memberId, productNo, qty):
            print('  수량이 수정되었습니다.')
        else:
            print('  수정에 실패했습니다. 상품번호 또는 재고를 확인하세요.')

    def removeCartItem(self):
        if not self.viewCart():
            return
        try:
            productNo = int(input('삭제할 상품 번호 : '))
        except ValueError:
            return
        memberId = self.authMgr.getLoginUser().get_id()
        if self.cartMgr.removeItem(memberId, productNo):
            print('  삭제되었습니다.')
        else:
            print('  장바구니에 없는 상품입니다.')

    def clearCart(self):
        memberId = self.authMgr.getLoginUser().get_id()
        if input('장바구니를 전체 비우시겠습니까? (y/n) : ').strip().lower() == 'y':
            self.cartMgr.clearCart(memberId)
            print('  장바구니를 비웠습니다.')

    # ----------------------------------------------------------
    # 주문/배송
    # ----------------------------------------------------------
    def orderProduct(self):
        self.header('주문하기')
        if not self.viewCart():
            return
        member = self.authMgr.getLoginUser()
        address = input(f'배송지 [{member.get_address()}] : ').strip()
        if not address:
            address = member.get_address()
        if not address:
            print('  배송지를 입력해야 합니다.')
            return
        if input('위 내용으로 주문하시겠습니까? (y/n) : ').strip().lower() != 'y':
            print('  주문을 취소했습니다.')
            return

        order, msg = self.orderMgr.createOrder(member.get_id())
        print(f'  {msg}')
        if order:
            self.deliveryMgr.createDelivery(order.get_orderNo(), address)
            print(f'  주문번호 {order.get_orderNo()}, 결제금액 {order.get_totalPrice():,}원')

    def viewOrderListAndDetail(self):
        self.header('주문 조회/상세')
        memberId = self.authMgr.getLoginUser().get_id()
        orders = self.orderMgr.listOrders(memberId)
        if not self.printOrders(orders):
            return
        value = input('상세 조회할 주문번호(엔터: 뒤로) : ').strip()
        if value:
            try:
                self.viewOrderDetail(int(value))
            except ValueError:
                print('  올바른 주문번호를 입력하세요.')

    def viewOrderDetail(self, orderNo):
        memberId = self.authMgr.getLoginUser().get_id()
        order = self.orderMgr.getOrder(orderNo)
        if not order or order.get_memberId() != memberId:
            print('  본인의 주문이 아니거나 존재하지 않습니다.')
            return
        self.printOrderDetail(order)

    def cancelOrder(self):
        self.header('주문 취소')
        memberId = self.authMgr.getLoginUser().get_id()
        orders = self.orderMgr.listOrders(memberId)
        if not self.printOrders(orders):
            return
        try:
            orderNo = int(input('취소할 주문번호 : '))
        except ValueError:
            return
        order = self.orderMgr.getOrder(orderNo)
        if not order or order.get_memberId() != memberId:
            print('  본인의 주문이 아니거나 존재하지 않습니다.')
            return
        delivery = self.deliveryMgr.getDelivery(orderNo)
        if delivery and delivery.get_status() in ['배송중', '배송완료']:
            print(f'  {delivery.get_status()} 상태에서는 주문을 취소할 수 없습니다.')
            return
        if input('정말 주문을 취소하시겠습니까? (y/n) : ').strip().lower() != 'y':
            return
        if self.orderMgr.cancelOrder(orderNo):
            self.deliveryMgr.markOrderCanceled(orderNo)
            print('  주문이 취소되었습니다. 재고가 복구되었습니다.')
        else:
            print('  주문 취소에 실패했습니다.')

    def viewDeliveryDetail(self):
        self.header('배송 상세 조회')
        try:
            orderNo = int(input('배송 조회할 주문번호 : '))
        except ValueError:
            return
        order = self.orderMgr.getOrder(orderNo)
        memberId = self.authMgr.getLoginUser().get_id()
        if not order or order.get_memberId() != memberId:
            print('  본인의 주문이 아니거나 존재하지 않습니다.')
            return
        delivery = self.deliveryMgr.getDelivery(orderNo)
        if delivery:
            print(f'  {delivery}')
        else:
            print('  배송 정보가 없습니다.')

    # ----------------------------------------------------------
    # 내 정보 / 회원 관리
    # ----------------------------------------------------------
    def viewMyInfo(self):
        self.header('내 정보 조회')
        print(f'  {self.authMgr.getLoginUser()}')

    def memberManageMenu(self):
        while True:
            menu = self.select_menu(MenuController.member_manage_menu, '회원 관리')
            if menu == 0:
                break
            elif menu == 1:
                self.listMembers()
            elif menu == 2:
                self.viewMemberDetail()
            elif menu == 3:
                self.deleteMember()
            else:
                print('  없는 메뉴입니다.')

    def listMembers(self):
        self.header('회원 목록')
        members = [m for m in self.memberMgr.listMembers() if not m.is_admin()]
        if not members:
            print('  가입한 회원이 없습니다.')
            return
        for m in members:
            print(f'  아이디 : {m.get_id()} | 이름 : {m.get_name()} | 전화번호 : {m.get_phone()}')

    def viewMemberDetail(self):
        id = input('조회할 회원 ID : ').strip()
        member = self.memberMgr.getMember(id)
        print(f'  {member}' if member else '  없는 ID입니다.')

    def deleteMember(self):
        id = input('삭제할 회원 ID : ').strip()
        if self.memberMgr.deleteMember(id):
            print('  회원이 삭제되었습니다.')
        else:
            print('  회원 삭제에 실패했습니다.')

    # ----------------------------------------------------------
    # 관리자 상품 관리
    # ----------------------------------------------------------
    def productManageMenu(self):
        while True:
            menu = self.select_menu(MenuController.product_manage_menu, '상품 관리')
            if menu == 0:
                break
            elif menu == 1:
                self.listProducts()
            elif menu == 2:
                self.addProduct()
            elif menu == 3:
                self.updateProduct()
            elif menu == 4:
                self.deleteProduct()
            else:
                print('  없는 메뉴입니다.')

    def addProduct(self):
        self.header('상품 등록')
        name = input('상품명 : ').strip()
        category = input('카테고리 : ').strip()
        try:
            price = int(input('가격 : '))
            stock = int(input('재고 : '))
        except ValueError:
            print('  올바른 값을 입력하세요.')
            return
        if not name or not category or price < 0 or stock < 0:
            print('  상품명/카테고리는 필수이고 가격/재고는 0 이상이어야 합니다.')
            return
        self.productMgr.addProduct(Product(name, category, price, stock))
        print('  상품이 등록되었습니다.')

    def updateProduct(self):
        self.listProducts()
        try:
            no = int(input('수정할 상품 번호 : '))
        except ValueError:
            return
        product = self.productMgr.getProduct(no)
        if not product:
            print('  존재하지 않는 상품입니다.')
            return
        print('  엔터만 누르면 기존 값을 유지합니다.')
        name = input(f'상품명 [{product.get_name()}] : ').strip()
        category = input(f'카테고리 [{product.get_category()}] : ').strip()
        price = input(f'가격 [{product.get_price()}] : ').strip()
        stock = input(f'재고 [{product.get_stock()}] : ').strip()

        if name: product.set_name(name)
        if category: product.set_category(category)
        if price:
            try: product.set_price(int(price))
            except ValueError: print('  가격 입력을 무시합니다.')
        if stock:
            try: product.set_stock(int(stock))
            except ValueError: print('  재고 입력을 무시합니다.')

        if self.productMgr.updateProduct(product):
            print('  상품 정보가 수정되었습니다.')

    def deleteProduct(self):
        self.listProducts()
        try:
            no = int(input('삭제할 상품 번호 : '))
        except ValueError:
            return
        if self.productMgr.deleteProduct(no):
            print('  상품이 삭제되었습니다.')
        else:
            print('  존재하지 않는 상품입니다.')

    # ----------------------------------------------------------
    # 관리자 주문/배송
    # ----------------------------------------------------------
    def listAllOrders(self):
        self.header('전체 주문 조회')
        orders = self.orderMgr.listAllOrders()
        self.printOrders(orders)

    def updateDeliveryStatus(self):
        self.header('배송 상태 수정')
        orders = self.orderMgr.listAllOrders()
        if not self.printOrders(orders):
            return
        try:
            orderNo = int(input('배송 상태를 수정할 주문번호 : '))
        except ValueError:
            return
        order = self.orderMgr.getOrder(orderNo)
        delivery = self.deliveryMgr.getDelivery(orderNo)
        if not order or not delivery:
            print('  주문 또는 배송 정보가 없습니다.')
            return
        if order.get_status() == '주문취소':
            print('  취소된 주문은 배송 상태를 수정할 수 없습니다.')
            return
        print('  1. 배송준비')
        print('  2. 배송중')
        print('  3. 배송완료')
        status_map = {1: '배송준비', 2: '배송중', 3: '배송완료'}
        try:
            status = status_map.get(int(input('변경할 상태 : ')))
        except ValueError:
            status = None
        if not status:
            print('  없는 상태입니다.')
            return
        self.deliveryMgr.updateStatus(orderNo, status)
        self.orderMgr.updateStatus(orderNo, status)
        print('  배송 상태가 수정되었습니다.')

    # ----------------------------------------------------------
    # 출력 보조
    # ----------------------------------------------------------
    def printOrders(self, orders):
        if not orders:
            print('  주문 내역이 없습니다.')
            return False
        for order in orders:
            delivery = self.deliveryMgr.getDelivery(order.get_orderNo())
            delivery_status = delivery.get_status() if delivery else '배송정보없음'
            print(f'  {order} | 배송상태 : {delivery_status}')
        return True

    def printOrderDetail(self, order):
        self.header('주문 상세')
        print(f'  {order}')
        delivery = self.deliveryMgr.getDelivery(order.get_orderNo())
        if delivery:
            print(f'  배송지 : {delivery.get_address()}')
            print(f'  배송상태 : {delivery.get_status()}')
        print('  주문 상품')
        for item in order.get_items():
            print(f'   - {item}')


if __name__ == '__main__':
    PetShopApp().main()
